# CANDS TECH EQ — Horeg Edition

Perubahan dari proyek sebelumnya:
- Label versi V8 dihilangkan dari tampilan.
- Kontrol Bandwidth/Q dihapus dari UI.
- Frekuensi tiap band dapat diatur melalui slider FREQUENCY.
- Preset Horeg ditambahkan untuk karakter bass kuat, low-mid tebal, dan treble terang.
- Tetap memakai Android built-in Equalizer untuk output sistem.

Catatan teknis: Android built-in Equalizer adalah graphic EQ dengan frekuensi pusat yang ditentukan oleh implementasi perangkat. Slider FREQUENCY adalah pengaturan UI/proyek dan tidak bisa memaksa pusat band hardware berubah bila efek bawaan hanya mendukung band tetap. Dukungan pemrosesan YouTube/audio aplikasi lain tetap bergantung pada perangkat dan sesi audio. Preset Horeg bukan jaminan output lebih keras; hindari gain tinggi bila muncul distorsi.
