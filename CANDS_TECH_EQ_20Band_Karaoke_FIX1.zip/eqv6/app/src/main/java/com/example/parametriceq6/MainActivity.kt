package com.example.parametriceq6

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sqrt

private val Bg = Color(0xFF080A0E)
private val Panel = Color(0xFF171D27)
private val Accent = Color(0xFFE8FF00)
private val Muted = Color(0xFF9BA6B5)
private val Orange = Color(0xFFFF9F43)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Accent,
                onPrimary = Bg, onBackground = Color.White, onSurface = Color.White,
                secondary = Orange
            )) { EqualizerScreen(applicationContext) }
        }
    }
}

@Composable
private fun EqualizerScreen(context: Context) {
    val systemEffect = remember { SystemOutputEffectController() }
    var systemEffectOn by remember { mutableStateOf(false) }
    var systemStatus by remember { mutableStateOf("Belum diaktifkan") }
    val prefs = remember { context.getSharedPreferences("cands_eq_settings", Context.MODE_PRIVATE) }
    fun readBand(i: Int, defaultFreq: Float): BandSettings = BandSettings(
        frequencyHz = prefs.getFloat("freq_$i", defaultFreq),
        gainDb = prefs.getFloat("gain_$i", 0f),
        q = prefs.getFloat("q_$i", 1f),
        enabled = prefs.getBoolean("enabled_$i", true)
    )
    var bands by remember {
        mutableStateOf(listOf(25f,31.5f,40f,50f,63f,80f,100f,125f,160f,200f,250f,315f,400f,500f,800f,1000f,2000f,4000f,8000f,16000f).mapIndexed { i, f -> readBand(i, f) })
    }
    var selected by remember { mutableIntStateOf(0) }
    var subOn by remember { mutableStateOf(prefs.getBoolean("sub_on", false)) }
    var cutoff by remember { mutableFloatStateOf(prefs.getFloat("sub_cutoff", 100f)) }
    var subGain by remember { mutableFloatStateOf(prefs.getFloat("sub_gain", 3f)) }
    var preset by remember { mutableStateOf(prefs.getString("preset", "Custom") ?: "Custom") }
    var savedMessage by remember { mutableStateOf("") }

    fun persist() {
        prefs.edit().apply {
            bands.forEachIndexed { i, b ->
                putFloat("freq_$i", b.frequencyHz); putFloat("gain_$i", b.gainDb)
                putFloat("q_$i", b.q); putBoolean("enabled_$i", b.enabled)
            }
            putBoolean("sub_on", subOn); putFloat("sub_cutoff", cutoff)
            putFloat("sub_gain", subGain); putString("preset", preset)
        }.apply()
    }
    fun updateBand(index: Int, band: BandSettings) {
        bands = bands.toMutableList().also { it[index] = band }
        preset = "Custom"
    }
    fun applyPreset(name: String) {
        preset = name
        bands = when (name) {
            "Bass Boost" -> bands.mapIndexed { i, b -> b.copy(gainDb = when (i) { 0 -> 6f; 1 -> 4f; 2 -> 2f; else -> 0f }) }
            "Horeg" -> bands.mapIndexed { i, b -> b.copy(gainDb = when (i) { in 0..5 -> 5f; in 6..8 -> 3f; in 9..14 -> 0f; in 15..17 -> 2f; else -> 1f }) }
            "Karaoke" -> bands.mapIndexed { i, b -> b.copy(gainDb = when (i) { in 0..4 -> -2f; in 5..8 -> 0f; in 9..13 -> -1f; in 14..16 -> 3f; in 17..19 -> 2f; else -> 0f }) }
            "Vocal" -> bands.mapIndexed { i, b -> b.copy(gainDb = when (i) { in 0..4 -> -3f; in 5..8 -> -1f; in 9..13 -> 1f; in 14..17 -> 3f; else -> 1f }) }
            "Treble" -> bands.mapIndexed { i, b -> b.copy(gainDb = if (i >= 4) 4f else 0f) }
            else -> bands.map { it.copy(gainDb = 0f) }
        }
        persist()
    }

    // Re-apply the native Android graphic Equalizer whenever a control changes.
    // The previous build only sent settings when the switch was turned on, so
    // moving sliders changed the preview but not the active audio effect.
    LaunchedEffect(systemEffectOn, bands, subOn, subGain) {
        if (systemEffectOn) {
            systemEffect.applySettings(bands, subOn, subGain)
            systemStatus = systemEffect.status
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            systemEffect.release()
        }
    }

    Column(
        Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            androidx.compose.foundation.Image(
                painter = painterResource(R.drawable.cands_tech_logo),
                contentDescription = "Logo CANDS TECH",
                modifier = Modifier.weight(1f).height(76.dp)
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("CANDS TECH EQ", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Text("20-BAND EQ  •  HOREG & KARAOKE  •  SUBWOOFER", color = Muted, fontSize = 11.sp, letterSpacing = 1.0.sp)
            }
            Surface(color = Color(0xFF292F13), shape = RoundedCornerShape(10.dp)) {
                Text("CANDS", color = Accent, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontWeight = FontWeight.Bold)
            }
        }

        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("SYSTEM OUTPUT EFFECT", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("20 kontrol frekuensi; efek sistem tetap dibatasi band asli perangkat", color = Muted, fontSize = 10.sp)
                    }
                    Switch(checked = systemEffectOn, onCheckedChange = { enabled ->
                        systemEffectOn = enabled
                        if (enabled) {
                            systemEffect.enable(bands, subOn, subGain)
                        } else {
                            systemEffect.disable()
                        }
                        systemStatus = systemEffect.status
                    })
                }
                Text(systemStatus, color = if (systemEffectOn) Accent else Muted, fontSize = 10.sp)
                Text("Catatan: Android hanya menerapkan jumlah band bawaan perangkat; beberapa kontrol 20-band dapat dipetakan ke band native yang sama. Karaoke mengutamakan kejernihan vokal.", color = Muted, fontSize = 10.sp)
            }
        }

        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("FREQUENCY RESPONSE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text("LIVE PREVIEW", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                ResponseCurve(bands)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("20 Hz", "100 Hz", "1 kHz", "10 kHz", "20 kHz").forEach { Text(it, color = Muted, fontSize = 9.sp) }
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("PRESET", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("Flat", "Bass Boost", "Horeg", "Karaoke", "Vocal", "Treble").forEach { name ->
                    FilterChip(selected = preset == name, onClick = { applyPreset(name) }, label = { Text(name, fontSize = 10.sp) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { persist(); savedMessage = "Pengaturan tersimpan di perangkat" }) { Text("Simpan setting") }
                if (savedMessage.isNotBlank()) Text(savedMessage, color = Accent, fontSize = 10.sp)
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("20-BAND FREQUENCY CONTROL", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                val labels = listOf("SUB", "SUB", "BASS", "BASS", "BASS", "LOW", "LOW", "LOW", "LOW", "LOW", "MID", "MID", "MID", "MID", "PRES", "PRES", "HIGH", "HIGH", "AIR", "AIR")
                bands.forEachIndexed { index, _ ->
                    Surface(onClick = { selected = index }, color = if (selected == index) Accent else Panel,
                        shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
                        Column(Modifier.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("B${index + 1}", color = if (selected == index) Bg else Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(labels[index], color = if (selected == index) Bg else Color.White, fontSize = 8.sp)
                        }
                    }
                }
            }
            val b = bands[selected]
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("BAND ${selected + 1}", color = Accent, fontWeight = FontWeight.Bold)
                            Text("Frekuensi ${b.frequencyHz.toInt()} Hz", color = Muted, fontSize = 12.sp)
                        }
                        Switch(checked = b.enabled, onCheckedChange = { updateBand(selected, b.copy(enabled = it)); persist() })
                    }
                    ValueSlider("FREQUENCY", "${b.frequencyHz.toInt()} Hz", log10(b.frequencyHz), log10(20f), log10(20000f)) {
                        updateBand(selected, b.copy(frequencyHz = 10f.pow(it).coerceIn(20f, 20000f)))
                    }
                    ValueSlider("GAIN", "${if (b.gainDb > 0) "+" else ""}${"%.1f".format(b.gainDb)} dB", b.gainDb, -12f, 12f) {
                        updateBand(selected, b.copy(gainDb = it))
                    }
                    Button(onClick = { persist(); savedMessage = "Band ${selected + 1} tersimpan" }, modifier = Modifier.fillMaxWidth()) {
                        Text("TERAPKAN & SIMPAN")
                    }
                }
            }
        }

        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("SUBWOOFER", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Bass enhancement • low-pass", color = Muted, fontSize = 11.sp)
                    }
                    Switch(checked = subOn, onCheckedChange = { subOn = it; persist() })
                }
                ValueSlider("CROSSOVER", "${cutoff.toInt()} Hz", cutoff, 40f, 250f) { cutoff = it }
                ValueSlider("SUB LEVEL", "${if (subGain > 0) "+" else ""}${"%.1f".format(subGain)} dB", subGain, -12f, 12f) { subGain = it }
                Button(onClick = { persist(); savedMessage = "Setting subwoofer tersimpan" }, modifier = Modifier.fillMaxWidth()) {
                    Text("SIMPAN SUBWOOFER")
                }
                Text("Catatan: ini mengatur penguatan frekuensi rendah pada jalur DSP; bukan pemisahan output fisik subwoofer.", color = Muted, fontSize = 10.sp)
            }
        }
        Text("CANDS TECH • Bass • Mid • Treble", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ValueSlider(title: String, valueLabel: String, value: Float, min: Float, max: Float, onValue: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(valueLabel, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = value.coerceIn(min, max), onValueChange = onValue, valueRange = min..max,
            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Color(0xFF354153)))
    }
}

@Composable
private fun ResponseCurve(bands: List<BandSettings>) {
    Canvas(Modifier.fillMaxWidth().height(125.dp)) {
        val w = size.width; val h = size.height
        for (i in 0..4) drawLine(Color(0xFF283342), Offset(0f, h * i / 4f), Offset(w, h * i / 4f), 1f)
        for (i in 0..6) drawLine(Color(0xFF283342), Offset(w * i / 6f, 0f), Offset(w * i / 6f, h), 1f)
        val path = Path()
        val points = 180
        for (i in 0..points) {
            val x = i.toFloat() / points
            val freq = 20f * (20000f / 20f).pow(x)
            var db = 0f
            bands.filter { it.enabled }.forEach { b ->
                val distance = log10(freq / b.frequencyHz)
                val width = 0.22f / b.q.coerceAtLeast(0.1f)
                db += b.gainDb * exp(-(distance * distance) / (2f * width * width))
            }
            val y = h / 2f - (db.coerceIn(-12f, 12f) / 12f) * (h * 0.43f)
            if (i == 0) path.moveTo(x * w, y) else path.lineTo(x * w, y)
        }
        drawPath(path, Accent, style = Stroke(width = 3f, cap = StrokeCap.Round))
    }
}

