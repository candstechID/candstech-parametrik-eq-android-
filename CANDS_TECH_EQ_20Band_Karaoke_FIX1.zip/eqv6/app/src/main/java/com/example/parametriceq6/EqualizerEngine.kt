package com.example.parametriceq6

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

data class BandSettings(
    val frequencyHz: Float,
    val gainDb: Float,
    val q: Float,
    val enabled: Boolean = true
)

/**
 * Twenty peaking-EQ biquads plus an optional low-pass subwoofer path.
 * Call process() on interleaved float PCM (L,R,L,R...) at the given sample rate.
 * This engine is not connected to system-wide Android audio automatically.
 */
class EqualizerEngine {
    var bands: List<BandSettings> = listOf(
        BandSettings(25f, 0f, 1.0f), BandSettings(31.5f, 0f, 1.0f), BandSettings(40f, 0f, 1.0f), BandSettings(50f, 0f, 1.0f), BandSettings(63f, 0f, 1.0f), BandSettings(80f, 0f, 1.0f), BandSettings(100f, 0f, 1.0f), BandSettings(125f, 0f, 1.0f), BandSettings(160f, 0f, 1.0f), BandSettings(200f, 0f, 1.0f), BandSettings(250f, 0f, 1.0f), BandSettings(315f, 0f, 1.0f), BandSettings(400f, 0f, 1.0f), BandSettings(500f, 0f, 1.0f), BandSettings(800f, 0f, 1.0f), BandSettings(1000f, 0f, 1.0f), BandSettings(2000f, 0f, 1.0f), BandSettings(4000f, 0f, 1.0f), BandSettings(8000f, 0f, 1.0f), BandSettings(16000f, 0f, 1.0f)
    )
    var subwooferEnabled: Boolean = false
    var subwooferCutoffHz: Float = 100f
    var subwooferGainDb: Float = 0f

    private val filters = Array(2) { Array(20) { Biquad() } }
    private val subFilters = Array(2) { Biquad() }

    fun process(interleaved: FloatArray, sampleRate: Int): FloatArray {
        if (sampleRate <= 0 || interleaved.isEmpty()) return interleaved
        val output = interleaved.copyOf()
        val safeBands = bands.take(20)
        for (ch in 0..1) {
            for (i in safeBands.indices) {
                val b = safeBands[i]
                filters[ch][i].setPeaking(sampleRate, b.frequencyHz, b.q, b.gainDb)
            }
            subFilters[ch].setLowPass(sampleRate, subwooferCutoffHz.coerceIn(30f, sampleRate * 0.45f), 0.707f)
        }
        var frame = 0
        while (frame + 1 < output.size) {
            for (ch in 0..1) {
                var x = output[frame + ch]
                for (i in safeBands.indices) {
                    if (safeBands[i].enabled) x = filters[ch][i].process(x)
                }
                if (subwooferEnabled) {
                    val low = subFilters[ch].process(x)
                    val linearGain = 10.0.pow(subwooferGainDb / 20.0).toFloat()
                    x = (x + low * (linearGain - 1f)).coerceIn(-1f, 1f)
                }
                output[frame + ch] = x.coerceIn(-1f, 1f)
            }
            frame += 2
        }
        return output
    }
}

private class Biquad {
    private var b0 = 1f; private var b1 = 0f; private var b2 = 0f
    private var a1 = 0f; private var a2 = 0f
    private var x1 = 0f; private var x2 = 0f
    private var y1 = 0f; private var y2 = 0f

    fun setPeaking(sampleRate: Int, frequency: Float, qValue: Float, gainDb: Float) {
        val f = frequency.coerceIn(20f, sampleRate * 0.45f)
        val q = qValue.coerceIn(0.1f, 10f)
        val a = 10.0.pow(gainDb / 40.0).toFloat()
        val w0 = (2.0 * PI * f / sampleRate).toFloat()
        val alpha = sin(w0) / (2f * q)
        val c = cos(w0)
        val a0 = 1f + alpha / a
        b0 = (1f + alpha * a) / a0
        b1 = (-2f * c) / a0
        b2 = (1f - alpha * a) / a0
        a1 = (-2f * c) / a0
        a2 = (1f - alpha / a) / a0
    }

    fun setLowPass(sampleRate: Int, frequency: Float, q: Float) {
        val w0 = (2.0 * PI * frequency / sampleRate).toFloat()
        val c = cos(w0)
        val alpha = sin(w0) / (2f * q)
        val a0 = 1f + alpha
        b0 = ((1f - c) / 2f) / a0
        b1 = (1f - c) / a0
        b2 = ((1f - c) / 2f) / a0
        a1 = (-2f * c) / a0
        a2 = (1f - alpha) / a0
    }

    fun process(x: Float): Float {
        val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1; x1 = x; y2 = y1; y1 = y
        return y
    }
}
