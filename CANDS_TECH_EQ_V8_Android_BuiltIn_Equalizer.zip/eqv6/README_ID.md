# CANDS TECH EQ V8 — Android Built-in Equalizer

Versi ini memakai `android.media.audiofx.Equalizer` bawaan Android untuk graphic EQ.

Perbaikan utama dari V7:
- Perubahan gain, enable band, preset, dan sub level dikirim ulang saat nilai kontrol berubah, selama EQ diaktifkan.
- Efek dilepas saat layar/aplikasi dibuang.
- Versi aplikasi dinaikkan ke 1.2 (versionCode 3).

Catatan kompatibilitas penting:
- `Equalizer(0, 0)` adalah jalur legacy output-mix. Android/OEM dapat menolak atau mengabaikannya; status aktif tidak membuktikan audio YouTube pasti diproses.
- Graphic Equalizer Android hanya menyediakan band bawaan perangkat. Frekuensi/Q yang tampil di aplikasi dipetakan ke band terdekat, bukan filter parametric sejati.
- Ini adalah proyek sumber untuk dibangun melalui GitHub Actions; APK belum dibangun atau diuji pada perangkat fisik di lingkungan ini.
