# CANDS TECH EQ V7 (RTA removed)

This project keeps the existing CANDS TECH EQ layout and removes the RTA panel and microphone permission.

## Important audio limitation
The current UI is an equalizer controller. The six-band `EqualizerEngine` is a PCM DSP engine, but this UI does not yet route an audio player through that engine. The system-output switch is best-effort only: Android documents attaching an Equalizer to global output session 0 as deprecated, and device/OEM support varies. Do not assume that moving the sliders changes YouTube, Spotify, TikTok, or game audio.

The parametric EQ engine can only change audio when an app-owned playback path actually passes PCM through `EqualizerEngine.process()`. The current version does not include that player path. The switch reports whether the Android effect was created/enabled, not proof that all system audio is being processed.

## Build on GitHub Actions
Upload this ZIP to the repository root, replacing older project ZIPs, then run the existing Build CANDS TECH EQ APK workflow. The APK build itself has not been verified in this environment.

## Project structure
- `app/src/main/java/com/example/parametriceq6/MainActivity.kt` — existing EQ UI, without RTA
- `EqualizerEngine.kt` — six-band parametric PCM DSP engine
- `SystemOutputEffectController.kt` — best-effort Android system effect controller
