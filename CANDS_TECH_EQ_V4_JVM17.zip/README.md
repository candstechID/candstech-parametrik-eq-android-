# Parametric EQ 6 (Android starter)

Prototype aplikasi Android menggunakan Kotlin + Jetpack Compose. Memiliki UI 6-band parametric EQ, frekuensi, gain, Q/bandwidth, preset, kurva respons, dan kontrol subwoofer.

## Build
1. Buka folder ini dengan Android Studio versi baru.
2. Gunakan JDK 17.
3. Sync Gradle lalu jalankan di perangkat/emulator Android 8.0 (API 26) atau lebih baru.

## Penting
- `EqualizerEngine.kt` berisi DSP biquad yang memproses PCM float interleaved stereo. Contoh pemanggilan:
  `val processed = engine.process(pcmFloatStereo, sampleRate)`
- UI saat ini adalah prototipe kontrol dan belum terhubung ke pemutar audio; untuk mendengar efeknya, integrasikan engine ke jalur audio aplikasi (misalnya pemutar berbasis AudioTrack/Media3 dengan PCM processing).
- Android tidak mengizinkan aplikasi biasa mengubah seluruh audio dari semua aplikasi secara universal. Efek sistem-wide bergantung pada dukungan perangkat/vendor atau akses khusus.
- Subwoofer di sini adalah low-frequency enhancement pada sinyal stereo, bukan output fisik terpisah ke speaker subwoofer.
- Untuk penggunaan produksi, tambahkan audio source/player, permission bila diperlukan, pengujian stabilitas DSP, limiter/anti-clipping, dan penyimpanan preset.
\n\n## Logo\nLogo CANDS TECH dari pengguna ditambahkan sebagai ikon launcher Android pada folder `app/src/main/res/mipmap-*` dan aset asli berada di `drawable/cands_tech_logo.png`. Ikon launcher memakai crop persegi dengan latar hitam agar sesuai dengan format ikon Android.\n

## Pengembangan lanjutan v2
- Logo CANDS TECH tampil pada header aplikasi.
- Ikon launcher diperbaiki agar logo lebar tidak terpotong.
- Pengaturan band, subwoofer, dan preset disimpan secara lokal dengan SharedPreferences.
- Preset tambahan Treble.
- Catatan: UI belum dihubungkan ke input/output pemutar audio. `EqualizerEngine` tersedia sebagai dasar DSP PCM stereo dan perlu dipasang ke jalur pemrosesan audio untuk mendengar perubahan.


## V3 — system-output compatibility mode
- Added a best-effort `Equalizer(0, 0)` system output-mix effect toggle. It attempts to affect audio from other apps only on devices/firmware that allow global session-0 effects.
- This is not guaranteed to affect YouTube/Spotify on every Android device. Android does not provide ordinary third-party apps a universal supported API to intercept and rewrite every other app's output.
- System output mode maps six UI bands to the nearest native graphic-EQ bands. Q/bandwidth and true low-pass crossover cannot be represented by Android's legacy graphic `Equalizer`.
- Full six-band parametric biquad DSP + low-frequency enhancement is implemented in `EqualizerEngine.kt`, but it requires PCM audio routed through an app-owned playback path. For robust all-app processing, the app needs OEM/system integration, root/privileged access, or a compatible audio-effects framework supplied by the device.
- The UI reports best-effort status; actual audible behavior must be tested on the target device.
