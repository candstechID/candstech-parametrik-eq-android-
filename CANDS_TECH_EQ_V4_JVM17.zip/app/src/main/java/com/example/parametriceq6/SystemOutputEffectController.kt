package com.example.parametriceq6

import android.media.audiofx.Equalizer
import kotlin.math.abs

/**
 * Best-effort Android output-mix compatibility effect.
 *
 * sessionId=0 is a legacy global output mix effect on devices that permit it.
 * OEMs/Android versions may reject or ignore it. Android's built-in Equalizer
 * is graphic EQ, so it cannot apply user Q/bandwidth values or a true subwoofer
 * crossover. The full parametric biquad engine remains available for app-owned PCM.
 */
class SystemOutputEffectController {
    private var effect: Equalizer? = null
    var status: String = "Belum diaktifkan"
        private set

    fun enable(bands: List<BandSettings>, subwooferOn: Boolean, subGainDb: Float): Boolean {
        return try {
            if (effect == null) effect = Equalizer(0, 0)
            val eq = effect ?: return false
            eq.enabled = false
            applySettings(bands, subwooferOn, subGainDb)
            eq.enabled = true
            status = "Efek output sistem aktif (jika didukung perangkat)"
            true
        } catch (e: Exception) {
            status = "Tidak didukung perangkat: ${e.javaClass.simpleName}"
            false
        }
    }

    fun applySettings(bands: List<BandSettings>, subwooferOn: Boolean, subGainDb: Float) {
        try {
            val eq = effect ?: return
            val range = eq.bandLevelRange
            val minLevel = range[0].toInt()
            val maxLevel = range[1].toInt()
            val numberOfBands = eq.numberOfBands.toInt()
            for (nativeBand in 0 until numberOfBands) {
                val centerHz = eq.getCenterFreq(nativeBand.toShort()).toFloat() / 1000f
                val closest = bands.filter { it.enabled }.minByOrNull { abs(it.frequencyHz - centerHz) }
                var gain = closest?.gainDb ?: 0f
                if (subwooferOn && centerHz <= 250f) gain += subGainDb
                val level = (gain * 100f).toInt().coerceIn(minLevel, maxLevel)
                eq.setBandLevel(nativeBand.toShort(), level.toShort())
            }
            status = "Pengaturan dikirim ke output EQ perangkat"
        } catch (e: Exception) {
            status = "Gagal menerapkan pengaturan: ${e.javaClass.simpleName}"
        }
    }

    fun disable() {
        try { effect?.enabled = false } catch (_: Exception) {}
        status = "Efek output dinonaktifkan"
    }

    fun release() {
        try { effect?.release() } catch (_: Exception) {}
        effect = null
        status = "Efek dilepas"
    }
}
