package com.cands.eq8band

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.util.Log

class StockEqualizerController {
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    var status: String = "Belum diaktifkan"
        private set

    val bandFrequencies = listOf(30f, 60f, 125f, 250f, 500f, 1000f, 4000f, 12000f)
    var bandLevels = FloatArray(8) { 0f }
    var bassStrength: Short = 500
    var isBassEnabled: Boolean = true

    fun enable(audioSession: Int = 0): Boolean {
        return try {
            if (equalizer == null) {
                equalizer = Equalizer(0, audioSession)
            }
            if (bassBoost == null) {
                bassBoost = BassBoost(0, audioSession)
            }
            equalizer?.enabled = true
            bassBoost?.enabled = isBassEnabled
            if (isBassEnabled) {
                bassBoost?.setStrength(bassStrength)
            }
            applyAllBands()
            status = "Stock Android EQ (8-Band) Aktif"
            true
        } catch (e: Exception) {
            status = "Gagal mengaktifkan: ${e.javaClass.simpleName}"
            false
        }
    }

    fun applyAllBands() {
        val eq = equalizer ?: return
        try {
            val numBands = eq.numberOfBands.toInt()
            val range = eq.bandLevelRange
            val minL = range[0].toInt()
            val maxL = range[1].toInt()

            for (i in 0 until 8) {
                if (i < numBands) {
                    val gainMillibels = (bandLevels[i] * 100).toInt().coerceIn(minL, maxL)
                    eq.setBandLevel(i.toShort(), gainMillibels.toShort())
                }
            }
        } catch (e: Exception) {
            Log.e("StockEQ", "Error applying bands", e)
        }
    }

    fun setBandGain(index: Int, gainDb: Float) {
        if (index in 0..7) {
            bandLevels[index] = gainDb
            applyAllBands()
        }
    }

    fun setBass(enabled: Boolean, strength: Short) {
        isBassEnabled = enabled
        bassStrength = strength
        try {
            bassBoost?.let {
                it.enabled = enabled
                if (enabled) it.setStrength(strength)
            }
        } catch (e: Exception) {
            Log.e("StockEQ", "Error setting bass boost", e)
        }
    }

    fun disable() {
        try {
            equalizer?.enabled = false
            bassBoost?.enabled = false
        } catch (_: Exception) {}
        status = "Dinonaktifkan"
    }

    fun release() {
        try {
            equalizer?.release()
            bassBoost?.release()
        } catch (_: Exception) {}
        equalizer = null
        bassBoost = null
        status = "Dilepas"
    }
}
