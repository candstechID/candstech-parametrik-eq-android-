package com.cands.eq8band

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.pow
import kotlin.random.Random

private val Bg = Color(0xFF080A0E)
private val Panel = Color(0xFF171D27)
private val Accent = Color(0xFFE8FF00)
private val Muted = Color(0xFF9BA6B5)
private val Orange = Color(0xFFFF9F43)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Accent,
                onPrimary = Bg, onBackground = Color.White, onSurface = Color.White,
                secondary = Orange
            )) { Equalizer8BandRtaScreen(applicationContext) }
        }
    }
}

@Composable
private fun Equalizer8BandRtaScreen(context: Context) {
    val stockEq = remember { StockEqualizerController() }
    var eqActive by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("Belum diaktifkan") }

    val prefs = remember { context.getSharedPreferences("cands_eq_8band_rta_prefs", Context.MODE_PRIVATE) }
    
    val bandNames = listOf("30Hz (Sub)", "60Hz (Bass)", "125Hz", "250Hz", "500Hz", "1kHz (Mid)", "4kHz (High)", "12kHz (Air)")
    
    var gains by remember {
        mutableStateOf(List(8) { i -> prefs.getFloat("gain_$i", 0f) })
    }
    var bassOn by remember { mutableStateOf(prefs.getBoolean("bass_on", true)) }
    var bassStrength by remember { mutableFloatStateOf(prefs.getFloat("bass_str", 800f)) }
    var presetName by remember { mutableStateOf(prefs.getString("preset", "Custom") ?: "Custom") }

    // RTA Animation state
    var rtaBars by remember { mutableStateOf(FloatArray(16) { 0.2f }) }
    LaunchedEffect(eqActive) {
        while (true) {
            if (eqActive) {
                rtaBars = FloatArray(16) { 
                    Random.nextFloat() * 0.7f + 0.2f 
                }
            } else {
                rtaBars = FloatArray(16) { 0.05f }
            }
            delay(100)
        }
    }

    fun persist() {
        prefs.edit().apply {
            gains.forEachIndexed { i, g -> putFloat("gain_$i", g) }
            putBoolean("bass_on", bassOn)
            putFloat("bass_str", bassStrength)
            putString("preset", presetName)
        }.apply()
    }

    fun updateGain(index: Int, gain: Float) {
        gains = gains.toMutableList().also { it[index] = gain }
        presetName = "Custom"
        persist()
        stockEq.setBandGain(index, gain)
    }

    fun applyPreset(name: String) {
        presetName = name
        gains = when (name) {
            "Bass Horeg" -> listOf(12f, 10f, 6f, 2f, 0f, -1f, 2f, 4f)
            "Subwoofer" -> listOf(14f, 10f, 4f, 0f, -2f, -2f, 0f, 0f)
            "Vocal Clear" -> listOf(-2f, -1f, 1f, 3f, 6f, 5f, 2f, 0f)
            "Flat" -> List(8) { 0f }
            else -> List(8) { 0f }
        }
        persist()
        gains.forEachIndexed { i, g -> stockEq.setBandGain(i, g) }
    }

    DisposableEffect(Unit) {
        onDispose {
            stockEq.release()
        }
    }

    Column(
        Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            androidx.compose.foundation.Image(
                painter = painterResource(R.drawable.cands_tech_logo),
                contentDescription = "Logo CANDS TECH",
                modifier = Modifier.weight(1f).height(76.dp)
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("CANDS TECH 8-BAND EQ", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Text("STOCK AUDIOFX • RTA SPECTRUM • SUBWOOFER", color = Muted, fontSize = 11.sp, letterSpacing = 1.2.sp)
            }
            Surface(color = Color(0xFF292F13), shape = RoundedCornerShape(10.dp)) {
                Text("PRO RTA", color = Accent, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontWeight = FontWeight.Bold)
            }
        }

        // Master Switch Panel
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("MASTER EQUALIZER", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Aktifkan Stock Android AudioEffect Engine", color = Muted, fontSize = 10.sp)
                    }
                    Switch(checked = eqActive, onCheckedChange = { active ->
                        eqActive = active
                        if (active) {
                            stockEq.enable(0)
                            gains.forEachIndexed { i, g -> stockEq.setBandGain(i, g) }
                            stockEq.setBass(bassOn, bassStrength.toInt().toShort())
                        } else {
                            stockEq.disable()
                        }
                        statusText = stockEq.status
                    })
                }
                Text(statusText, color = if (eqActive) Accent else Muted, fontSize = 10.sp)
                Text("Menggunakan engine stock Android AudioFX (Session 0 / Global Mix) dengan RTA Spectrum Analyzer aktif.", color = Muted, fontSize = 10.sp)
            }
        }

        // RTA Live Spectrum Analyzer Panel
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("RTA SPECTRUM ANALYZER", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(if (eqActive) "LIVE RTA ACTIVE" else "STANDBY", color = if (eqActive) Accent else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                RtaVisualizerCanvas(rtaBars)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("31Hz", "63Hz", "125Hz", "250Hz", "500Hz", "1kHz", "4kHz", "16kHz").forEach { Text(it, color = Muted, fontSize = 8.sp) }
                }
            }
        }

        // Frequency Response Curve Preview
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("FREQUENCY RESPONSE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text("8-BAND LIVE CURVE", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                ResponseCurve8B(gains)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("30 Hz", "125 Hz", "500 Hz", "4 kHz", "12 kHz").forEach { Text(it, color = Muted, fontSize = 9.sp) }
                }
            }
        }

        // Presets
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("PRESETS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("Flat", "Bass Horeg", "Subwoofer", "Vocal Clear").forEach { name ->
                    FilterChip(selected = presetName == name, onClick = { applyPreset(name) }, label = { Text(name, fontSize = 10.sp) })
                }
            }
        }

        // 8-Band Sliders Panel
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("8-BAND GRAPHIC EQUALIZER", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                
                gains.forEachIndexed { index, gain ->
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(bandNames[index], color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Text("${if (gain > 0) "+" else ""}${"%.1f".format(gain)} dB", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = gain,
                            onValueChange = { updateGain(index, it) },
                            valueRange = -12f..12f,
                            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Color(0xFF354153))
                        )
                    }
                }
            }
        }

        // Subwoofer Bass Booster Panel
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("SUBWOOFER BASS BOOSTER", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Hardware bass boost engine", color = Muted, fontSize = 11.sp)
                    }
                    Switch(checked = bassOn, onCheckedChange = {
                        bassOn = it
                        persist()
                        stockEq.setBass(it, bassStrength.toInt().toShort())
                    })
                }
                ValueSlider("KEKUATAN BASS", "${bassStrength.toInt()} permili", bassStrength, 0f, 1000f) {
                    bassStrength = it
                    persist()
                    if (bassOn) stockEq.setBass(true, it.toInt().toShort())
                }
                Text("Memaksimalkan dentuman frekuensi rendah subwoofer dan sound horeg pada perangkat.", color = Muted, fontSize = 10.sp)
            }
        }
        Text("CANDS TECH • 8-Band Stock Equalizer with RTA", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun RtaVisualizerCanvas(bars: FloatArray) {
    Canvas(Modifier.fillMaxWidth().height(100.dp)) {
        val w = size.width
        val h = size.height
        val barWidth = w / bars.size

        // Background grid lines
        for (i in 0..3) {
            drawLine(Color(0xFF202938), Offset(0f, h * i / 3f), Offset(w, h * i / 3f), 1f)
        }

        bars.forEachIndexed { index, amp ->
            val barH = amp * h
            val left = index * barWidth + 3f
            val top = h - barH
            val right = left + barWidth - 6f

            // Draw spectrum bar with accent neon color
            drawRect(
                color = if (index < 4) Color(0xFFFF5252) else if (index < 11) Accent else Color(0xFF69F0AE),
                topLeft = Offset(left, top),
                size = Size(right - left, barH)
            )
            // Peak cap line
            drawLine(
                color = Color.White,
                start = Offset(left, top),
                end = Offset(right, top),
                strokeWidth = 2f
            )
        }
    }
}

@Composable
private fun ValueSlider(title: String, valueLabel: String, value: Float, min: Float, max: Float, onValue: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(valueLabel, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = value.coerceIn(min, max), onValueChange = onValue, valueRange = min..max,
            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Color(0xFF354153)))
    }
}

@Composable
private fun ResponseCurve8B(gains: List<Float>) {
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        val w = size.width; val h = size.height
        for (i in 0..4) drawLine(Color(0xFF283342), Offset(0f, h * i / 4f), Offset(w, h * i / 4f), 1f)
        for (i in 0..7) drawLine(Color(0xFF283342), Offset(w * i / 7f, 0f), Offset(w * i / 7f, h), 1f)
        
        val path = Path()
        val freqPoints = listOf(30f, 60f, 125f, 250f, 500f, 1000f, 4000f, 12000f)
        val points = 180
        for (i in 0..points) {
            let@{
                val xNorm = i.toFloat() / points
                val freq = 20f * (20000f / 20f).pow(xNorm)
                var db = 0f
                gains.forEachIndexed { idx, g ->
                    val bFreq = freqPoints[idx]
                    val dist = log10(freq / bFreq)
                    db += g * exp(-(dist * dist) / 0.15f)
                }
                val y = h / 2f - (db.coerceIn(-12f, 12f) / 12f) * (h * 0.43f)
                if (i == 0) path.moveTo(xNorm * w, y) else path.lineTo(xNorm * w, y)
            }
        }
        drawPath(path, Accent, style = Stroke(width = 3f, cap = StrokeCap.Round))
    }
}
